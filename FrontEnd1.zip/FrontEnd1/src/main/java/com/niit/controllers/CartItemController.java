package com.niit.controllers;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.dao.CartItemDao;
import com.niit.dao.ProductDao;
import com.niit.models.CartItem;
import com.niit.models.Customer;
import com.niit.models.Product;
import com.niit.models.ShippingAddress;
import com.niit.models.User;

@Controller
public class CartItemController {
	@Autowired
private CartItemDao cartItemDao;
	@Autowired
		private ProductDao productDao;
	/*@RequestMapping(value="/cart/addtocart/{productId}")
		public String addToCart(@PathVariable int productId, @RequestParam int requestQuantity,@AuthenticationPrincipal Principal principal)
		{ //in jsp userPrincipal, in controller Principal
			if(principal==null)
				return "Login";
			String email=principal.getName();
			Product product=product.getProduct(id);
			User user=cartItemDao.getUser(email);
			List<CartItem> cartItem=cartItemDao.getCart(email);
			for(CartItem cartItem1:cartItem){
				if(cartItem1.getProduct().getId()==productId){
					cartItem1.setQuantity(requestQuantity);
					cartItem1.getTotalPrice(requestQuantity*product.getPrice());
					cartItemDao.addToCart1(cartItem1); //update the quantity and totalprice
					return "redirect:/cart/getcart";
				}
			}
			CartItem cartItem1=new CartItem();
			cartItem1.setQuantity(requestQuantity);
		cartItem1.setProduct(product);
		cartItem1.setUser(user);
		double totalPrice=requestQuantity*product.getPrice();
		cartItem1.setTotalPrice(totalPrice);
		cartItemDao.addToCart1(cartItem1);
		return "redirect:/cart/getcart";
		}*/
		@RequestMapping(value="/cart/getcart")
	public String getCart(@AuthenticationPrincipal Principal principal,Model model){
		if(principal==null)
			return "login";
		String email=principal.getName();
		List<CartItem> cartItem=cartItemDao.getCart(email);
		model.addAttribute("cartItem",cartItem);
		return "cart";
		//select * from cartitem where user_email=? - to execute the query redirect/cart/getcart
	}
	public String clearCart(@AuthenticationPrincipal Principal principal){
		//Get list of cartItem
		List<CartItem> cartItem=cartItemDao.getCart(principal.getName());
		for(CartItem cartItem1:cartItem){
			cartItemDao.removeCartItem(cartItem1.getCartItemId());
			//delete from cartItem where cartItemid=?
		}
		return "redirect:/cart/getcart";
		}
	public String getShippingAddressForm(@AuthenticationPrincipal Principal principal,Model model){
		if(principal==null)
			return "login";
		String email=principal.getName();
		User user=cartItemDao.getUser(email);
		Customer customer=user.getCustomer();
		ShippingAddress shippingAddress=customer.getShippingaddress();
		model.addAttribute("shippingaddress",shippingAddress);
		return "shippingaddress";
	}
}
