package com.niit.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.niit.dao.ProductDao;

@Controller
public class HomeControl {
	@Autowired
	private ProductDao productDao;
	public HomeControl()
	{
		System.out.println("Home Controller");
	}

@RequestMapping(value ="/home")
public  String homepage(HttpSession session){
	session.setAttribute("categories", productDao.getAllCategories());
	return "home";
}
@RequestMapping(value ="/aboutus")
public  String aboutUs(){
	System.out.println("home is exe");
	return "aboutus";
}
@RequestMapping(value="/login")
public String login(){
	return "login";	
}
@RequestMapping(value="/loginerror")
public String loginFailed(Model model){
	model.addAttribute("error","Invalid credentials...");
	return "login";
	
}
@RequestMapping(value="/logout")
public String logout(Model model){
	model.addAttribute("msg","Loggedout successfully...");
	return "login";
}
}

