package com.niit.dao;
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.configuration.DBConfig;
import com.niit.models.Product;

import junit.framework.TestCase;

public class ProductDaoImplTest1 extends TestCase
{
	ApplicationContext context=new AnnotationConfigApplicationContext(DBConfig.class,ProductDaoImpl.class);
    ProductDao productDao=(ProductDao)context.getBean("productDaoImpl");
    
    public void testSaveProduct()
    {
    	Product product=new Product();
    	product.setPrice(1001);
    	product.setQuantity(3);
    	product.setProductname("lenovo k8");
    	product.setProductdesc("Deca Core Processor");
    	product=productDao.saveProduct(product);
    }
    public void testGetProduct()
    {
    	
    }
    public void testUpdateProduct()
    {
    	Product product=productDao.getProduct(2);
    	product.setPrice(40000);
    	product.setQuantity(10);
    	productDao.updateProduct(product);
    	assertTrue(product.getPrice()!=2000);
    	assertTrue(product.getQuantity()!=25);	
    }
    public void testGetAllProducts()
    {
    	List<Product>products=productDao.getAllProducts();
    	assertTrue(products.size()>0);
    	assertFalse(products.isEmpty());
    }
}


